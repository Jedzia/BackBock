using System;
using System.Collections.Generic;
using System.Text;

namespace CustomEventArgs.Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            DirtyLake lakeNasty = new DirtyLake();
            Fisherman fman = new Fisherman(lakeNasty);

            for (int i = 0; i < 5; i++)
                fman.Fish();

            Console.ReadLine();
        }
    }

    public class Fisherman
    {
        #region Constructors

        public Fisherman(DirtyLake lake)
        {
            m_lake = lake;

            m_lake.DoubleCaught += SomethingCaught;
            m_lake.FishCaught += SomethingCaught;
            m_lake.GuidAndIntAndStringCaught += SomethingCaught;
            m_lake.StringAndDoubleCaught += SomethingCaught;
        }

        #endregion

        #region Member Variables

        private DirtyLake m_lake;

        #endregion

        #region Methods

        #region Event Handlers

        void SomethingCaught<T>(object sender, EventArgs<T> e)
        {
            Console.WriteLine(string.Format("We Caught Something: {0} - {1}\n\n", e.Value.GetType(), e.Value.ToString()));
        }

        void SomethingCaught<T, U>(object sender, EventArgs<T, U> e)
        {
            Console.WriteLine(string.Format("We Caught Two Things: {0} - {1} \nand {2} - {3}\n\n", 
                e.Value.GetType().ToString(), e.Value.ToString(),
                e.Value2.GetType().ToString(), e.Value2.ToString()));
        }

        void SomethingCaught<T, U, V>(object sender, EventArgs<T, U, V> e)
        {
            Console.WriteLine(string.Format("We Caught Three Things: {0} - {1} \nand {2} - {3} \nand {4} - {5}\n\n",
                e.Value.GetType(), e.Value.ToString(),
                e.Value2.GetType(), e.Value2.ToString(),
                e.Value3.GetType(), e.Value3.ToString()));
        }

        #endregion

        public void Fish()
        {
            m_lake.GetSomething();
        }

        #endregion
    }

    public class DirtyLake
    {
        #region Member Variables

        private String m_floatingThing1 = "Nasty Floating Thing";
        private Double m_floatingThing2 = 234.5678;
        private Guid m_floatingThing3 = Guid.NewGuid();
        private Int32 m_floatingThing4 = 3445;
        private Fish m_fish = new Fish("Ferdinand");


        Random rand = new Random();

        private event EventHandler<EventArgs<String, Double>> m_stringAndDoubleCaught;
        private event EventHandler<EventArgs<Double>> m_doubleCaught;
        private event EventHandler<EventArgs<Guid, int, string>> m_guidAndStringAndIntCaught;
        private event EventHandler<EventArgs<Fish>> m_fishCaught;

        #endregion

        #region Events

        public event EventHandler<EventArgs<String, Double>> StringAndDoubleCaught
        {
            add { m_stringAndDoubleCaught += value; }
            remove { m_stringAndDoubleCaught -= value; }
        }

        public event EventHandler<EventArgs<Double>> DoubleCaught
        {
            add { m_doubleCaught += value; }
            remove { m_doubleCaught -= value; }
        }

        public event EventHandler<EventArgs<Guid, Int32, string>> GuidAndIntAndStringCaught
        {
            add { m_guidAndStringAndIntCaught += value; }
            remove { m_guidAndStringAndIntCaught -= value; }
        }

        public event EventHandler<EventArgs<Fish>> FishCaught
        {
            add { m_fishCaught += value; }
            remove { m_fishCaught -= value; }
        }

        #endregion

        #region Method

        public void GetSomething()
        {
            switch(rand.Next(0,4))
            {
                case 0:
                    if (null != m_fishCaught)
                        m_fishCaught(this, new EventArgs<Fish>(m_fish));
                    break;
                case 1:
                    if(null != m_stringAndDoubleCaught)
                        m_stringAndDoubleCaught(this, new EventArgs<String, Double>(m_floatingThing1, m_floatingThing2));
                    break;
                case 2:
                    if(null != m_doubleCaught)
                        m_doubleCaught(this, new EventArgs<double>(m_floatingThing2));
                    break;
                case 3:
                    if(null != m_guidAndStringAndIntCaught)
                        m_guidAndStringAndIntCaught(this, new EventArgs<Guid, int, string>(m_floatingThing3, m_floatingThing4, m_floatingThing1));
                    break;
                default:
                    throw new Exception("Unexpected Thing Caught");

            }
        }

        #endregion
    }

    public class Fish
    {
        public Fish(string name)
        {
            m_name = name;
        }

        private string m_name;

        private string Name
        {
            get { return m_name; }
            set { m_name = value; }
        }
    }
}
